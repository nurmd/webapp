import{K as e}from"./index-5SGrcM_r.js";function o(){return typeof localStorage>"u"?!1:localStorage.getItem(e.DEMO_MODE)==="true"}export{o as i};

import{R as y,j as e}from"./vendor-react-BmrtlWLx.js";import{A as v,V as i,a as d,f as h,u as j,M as N,s as w}from"./index-5SGrcM_r.js";import"./vendor-capacitor-BjPRKokX.js";import"./vendor-pouchdb-cVEZlOt_.js";function k(t,a){const o=i(t.tradeName||t.businessName||"Business Enterprise"),l=i(t.address||""),p=i(t.phone||""),r=i(t.gstin||""),m=i(a.voucherNumber||a.id),c=i(a.voucherType),f=a.narration?i(a.narration):"",b=a.partyName?i(a.partyName):"",g=(a.entries||[]).map((s,x)=>`
    <tr style="border-bottom: 1px solid #e2e8f0; font-size: 11px;">
      <td style="padding: 7px 8px; text-align: center; color: #64748b;">${x+1}</td>
      <td style="padding: 7px 8px; font-weight: 600; color: #0f172a;">${i(s.accountName)}</td>
      <td style="padding: 7px 8px; text-align: right; color: ${s.debit>0?"#0f172a":"#94a3b8"}; font-weight: ${s.debit>0?"700":"400"};">
        ${s.debit>0?d(s.debit):"—"}
      </td>
      <td style="padding: 7px 8px; text-align: right; color: ${s.credit>0?"#0f172a":"#94a3b8"}; font-weight: ${s.credit>0?"700":"400"};">
        ${s.credit>0?d(s.credit):"—"}
      </td>
    </tr>
  `).join(""),n=(a.entries||[]).reduce((s,x)=>s+(x.debit||0),0),u=(a.entries||[]).reduce((s,x)=>s+(x.credit||0),0);return`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>Voucher #${m} - ${c}</title>
  <style>
    @page {
      size: A4 portrait;
      margin: 15mm;
    }
    * {
      box-sizing: border-box;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      padding: 24px;
      color: #1e293b;
      max-width: 680px;
      margin: 0 auto;
      background: #ffffff;
      line-height: 1.4;
    }
    .header {
      border-bottom: 2px solid #0f172a;
      padding-bottom: 12px;
      margin-bottom: 16px;
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
    }
    .company-name {
      font-size: 20px;
      font-weight: 800;
      color: #0f172a;
    }
    .voucher-title {
      font-size: 16px;
      font-weight: 800;
      text-transform: uppercase;
      color: #0284c7;
      text-align: right;
    }
    .company-meta {
      font-size: 11px;
      color: #64748b;
      margin-top: 2px;
    }
    .hero {
      background: #f8fafc;
      border: 1px solid #e2e8f0;
      border-radius: 8px;
      padding: 14px 16px;
      margin-bottom: 16px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .amount {
      font-size: 22px;
      font-weight: 800;
      color: #0f172a;
    }
    .grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 12px;
      margin-bottom: 16px;
      font-size: 12px;
    }
    .box {
      background: #f8fafc;
      border: 1px solid #e2e8f0;
      border-radius: 6px;
      padding: 9px 12px;
    }
    .label {
      font-size: 10px;
      text-transform: uppercase;
      font-weight: 700;
      color: #64748b;
      margin-bottom: 3px;
    }
    .val {
      font-weight: 600;
      color: #0f172a;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 10px;
      font-size: 11.5px;
    }
    th {
      background: #f1f5f9;
      color: #0f172a;
      font-weight: 700;
      border-top: 1px solid #cbd5e1;
      border-bottom: 2px solid #94a3b8;
      padding: 7px 8px;
    }
    tfoot td {
      background: #f8fafc;
      font-weight: 800;
      border-top: 2px solid #0f172a;
      border-bottom: 1px solid #cbd5e1;
      padding: 8px;
      color: #0f172a;
    }
    .narration {
      font-size: 11.5px;
      color: #475569;
      font-style: italic;
      margin-top: 14px;
      padding: 10px;
      background: #f8fafc;
      border-radius: 6px;
      border-left: 3px solid #0284c7;
    }
    .signatures {
      display: flex;
      justify-content: space-between;
      margin-top: 50px;
      font-size: 11.5px;
      font-weight: 600;
      color: #334155;
    }
    .sig-line {
      border-top: 1px dashed #94a3b8;
      padding-top: 6px;
      width: 180px;
      text-align: center;
    }
    .footer {
      border-top: 1px dashed #cbd5e1;
      margin-top: 30px;
      padding-top: 10px;
      font-size: 10px;
      text-align: center;
      color: #94a3b8;
    }
    @media print {
      body {
        padding: 0;
      }
      .no-print {
        display: none !important;
      }
    }
  </style>
</head>
<body>
  <div class="no-print" style="margin-bottom: 16px; display: flex; justify-content: flex-end; gap: 10px;">
    <button onclick="window.print()" style="padding: 8px 16px; background: #0284c7; color: #fff; border: none; border-radius: 6px; font-weight: bold; cursor: pointer;">Print / Save as PDF</button>
    <button onclick="window.close()" style="padding: 8px 16px; background: #e2e8f0; color: #0f172a; border: none; border-radius: 6px; font-weight: bold; cursor: pointer;">Close</button>
  </div>
  <div class="header">
    <div>
      <div class="company-name">${o}</div>
      <div class="company-meta">
        ${r?`<div>GSTIN: ${r}</div>`:""}
        ${l?`<div>${l}</div>`:""}
        ${p?`<div>Phone: ${p}</div>`:""}
      </div>
    </div>
    <div>
      <div class="voucher-title">${c} VOUCHER</div>
      <div style="font-size: 12px; font-weight: 700; color: #475569; text-align: right; margin-top: 2px;">
        #${m}
      </div>
      <div style="font-size: 11px; color: #64748b; text-align: right; margin-top: 2px;">
        Date: ${h(a.date)}
      </div>
    </div>
  </div>

  <div class="hero">
    <div>
      <div class="label">${b?"Party / Account":"Voucher Type"}</div>
      <div style="font-size: 15px; font-weight: 700;">${b||c}</div>
    </div>
    <div style="text-align: right;">
      <div class="label">Total Amount</div>
      <div class="amount">${d(a.totalAmount)}</div>
    </div>
  </div>

  <table>
    <thead>
      <tr>
        <th style="width: 35px; text-align: center;">#</th>
        <th style="text-align: left;">Account Head / Description</th>
        <th style="width: 130px; text-align: right;">Debit (₹)</th>
        <th style="width: 130px; text-align: right;">Credit (₹)</th>
      </tr>
    </thead>
    <tbody>
      ${g||'<tr><td colspan="4" style="text-align: center; padding: 15px; color: #94a3b8;">No accounting entries</td></tr>'}
    </tbody>
    <tfoot>
      <tr>
        <td colspan="2" style="text-align: right;">Total</td>
        <td style="text-align: right;">${d(n||a.totalAmount)}</td>
        <td style="text-align: right;">${d(u||a.totalAmount)}</td>
      </tr>
    </tfoot>
  </table>

  ${f?`<div class="narration"><strong>Narration:</strong> ${f}</div>`:""}

  <div class="signatures">
    <div class="sig-line">Prepared / Verified By</div>
    <div class="sig-line">Authorized Signatory</div>
  </div>

  <div class="footer">
    Generated by Vyapar Books PRO • Official Double-Entry Accounting Voucher
  </div>
</body>
</html>`}function $(t,a){const o=k(t,a);v(o,`Voucher-${a.voucherNumber||a.id}`,"A4")}const D=({voucher:t,company:a,parties:o,onClose:l})=>{j(()=>(l(),!0),!!t,25);const p=y.useMemo(()=>!(t!=null&&t.partyId)||!o||o.length===0?null:o.find(n=>n.id===t.partyId)||null,[t==null?void 0:t.partyId,o]);if(!t)return null;const r=t.voucherType==="RECEIPT",m=t.voucherType==="PAYMENT",c=r?"bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300":m?"bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300":"bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300",f=()=>{const n=N(t,p,a);w(`https://wa.me/?text=${encodeURIComponent(n)}`)},b=()=>{$(a,t)},g=t.entries||[];return e.jsx("div",{className:"fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 animate-fade-in",children:e.jsxs("div",{className:"bg-surface-container-lowest rounded-2xl w-full max-w-md shadow-2xl border border-outline-variant/30 flex flex-col max-h-[90vh] overflow-hidden",children:[e.jsxs("div",{className:"flex items-center justify-between border-b border-outline-variant/20 p-3.5 sm:p-4 flex-shrink-0",children:[e.jsxs("div",{className:"flex items-center gap-2.5 min-w-0",children:[e.jsx("div",{className:`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 ${r?"bg-emerald-50 text-emerald-600 dark:bg-emerald-950/60 dark:text-emerald-400":"bg-rose-50 text-rose-600 dark:bg-rose-950/60 dark:text-rose-400"}`,children:e.jsx("span",{className:"material-symbols-outlined text-[20px]",children:r?"payments":"account_balance_wallet"})}),e.jsxs("div",{className:"min-w-0",children:[e.jsxs("div",{className:"flex items-center gap-1.5 flex-wrap",children:[e.jsx("h3",{className:"font-bold text-sm text-on-surface truncate",children:t.voucherNumber}),e.jsx("span",{className:`text-[10px] font-bold px-2 py-0.5 rounded-full ${c}`,children:t.voucherType})]}),e.jsx("span",{className:"text-[11px] text-on-surface-variant font-medium",children:h(t.date)})]})]}),e.jsx("button",{type:"button",onClick:l,className:"min-w-[44px] min-h-[44px] w-11 h-11 rounded-full flex items-center justify-center text-on-surface-variant hover:bg-surface-container-low transition-colors cursor-pointer",title:"Close","aria-label":"Close voucher details",children:e.jsx("span",{className:"material-symbols-outlined text-[20px]",children:"close"})})]}),e.jsxs("div",{className:"flex-1 overflow-y-auto p-3.5 sm:p-4 space-y-3.5",children:[e.jsxs("div",{className:"p-3.5 rounded-xl bg-surface-container-low/60 border border-outline-variant/20 flex items-center justify-between",children:[e.jsxs("div",{className:"flex flex-col",children:[e.jsx("span",{className:"text-[11px] uppercase font-bold text-on-surface-variant tracking-wider",children:"Voucher Amount"}),e.jsx("span",{className:`font-tabular-data text-2xl font-black mt-0.5 ${r?"text-emerald-600 dark:text-emerald-400":"text-rose-600 dark:text-rose-400"}`,children:d(t.totalAmount)})]}),e.jsxs("div",{className:`px-2.5 py-1 rounded-xl text-xs font-bold flex items-center gap-1 ${r?"bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300":"bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300"}`,children:[e.jsx("span",{className:"material-symbols-outlined text-[15px]",children:r?"south_west":"north_east"}),e.jsx("span",{children:r?"Money In":"Money Out"})]})]}),t.narration&&e.jsxs("div",{className:"p-3 rounded-xl bg-surface-container-low/40 border border-outline-variant/15 text-xs text-on-surface",children:[e.jsx("span",{className:"font-bold text-on-surface-variant block text-[10px] uppercase mb-0.5",children:"Narration / Details"}),e.jsx("p",{className:"font-medium leading-relaxed",children:t.narration})]}),t.referenceNo&&e.jsxs("div",{className:"flex items-center justify-between text-xs px-1 text-on-surface-variant",children:[e.jsx("span",{children:"Reference Number:"}),e.jsx("span",{className:"font-mono font-bold text-on-surface",children:t.referenceNo})]}),e.jsxs("div",{children:[e.jsx("span",{className:"text-[11px] font-bold uppercase text-on-surface-variant tracking-wider block mb-1.5 px-1",children:"Double-Entry Ledger Lines"}),e.jsx("div",{className:"rounded-xl border border-outline-variant/20 overflow-hidden divide-y divide-outline-variant/15",children:g.length===0?e.jsx("div",{className:"p-3 text-center text-xs text-on-surface-variant font-medium",children:"No ledger lines recorded."}):g.map((n,u)=>e.jsxs("div",{className:"p-2.5 bg-surface-container-low/30 flex items-center justify-between text-xs",children:[e.jsxs("div",{className:"flex flex-col min-w-0 pr-2",children:[e.jsx("span",{className:"font-bold text-on-surface truncate",children:n.accountName||n.accountId}),n.narration&&e.jsx("span",{className:"text-[10px] text-on-surface-variant truncate",children:n.narration})]}),e.jsxs("div",{className:"flex items-center gap-3 flex-shrink-0 text-right font-mono font-bold",children:[n.debit>0&&e.jsxs("span",{className:"text-blue-600 dark:text-blue-400",children:["Dr ",d(n.debit)]}),n.credit>0&&e.jsxs("span",{className:"text-emerald-600 dark:text-emerald-400",children:["Cr ",d(n.credit)]})]})]},u))})]})]}),e.jsxs("div",{className:"p-3 sm:p-4 border-t border-outline-variant/20 bg-surface-container-low/40 flex items-center justify-between gap-2 flex-shrink-0",children:[e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsxs("button",{type:"button",onClick:f,className:"min-h-[44px] px-3.5 py-2.5 rounded-xl bg-emerald-600 text-white font-bold text-xs flex items-center justify-center gap-1.5 hover:bg-emerald-700 active:scale-95 transition-all cursor-pointer shadow-xs",children:[e.jsx("span",{className:"material-symbols-outlined text-[16px]",children:"share"}),e.jsx("span",{children:"Share"})]}),e.jsxs("button",{type:"button",onClick:b,className:"min-h-[44px] px-3.5 py-2.5 rounded-xl bg-surface-container-lowest text-on-surface border border-outline-variant/30 font-bold text-xs flex items-center justify-center gap-1.5 hover:bg-surface-container active:scale-95 transition-all cursor-pointer",children:[e.jsx("span",{className:"material-symbols-outlined text-[16px]",children:"print"}),e.jsx("span",{children:"Print"})]})]}),e.jsx("button",{type:"button",onClick:l,className:"min-h-[44px] px-5 py-2.5 rounded-xl bg-secondary text-on-secondary font-bold text-xs active:scale-95 transition-all cursor-pointer shadow-xs flex items-center justify-center",children:"Close"})]})]})})};export{D as DashboardVoucherModal};

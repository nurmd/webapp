import{r as m,j as e}from"./vendor-react-BmrtlWLx.js";import{a as j,f as A,N as D,s as T,u as C,F as I,G as S}from"./index-5SGrcM_r.js";import{i as U}from"./demoMode-C1eVaD0P.js";import{s as f}from"./toast-BCRlPXny.js";const M={invoice:{en:`Dear {customer_name},

Thank you for choosing *{store_name}*! 🙏

🧾 *Invoice:* #{invoice_no}
📅 *Date:* {date}
💰 *Total Amount:* {amount}

💳 *Pay via UPI:*
{upi_link}

We look forward to serving you again!`,hi:`नमस्ते {customer_name},

*{store_name}* से ख़रीदारी करने के लिए धन्यवाद! 🙏

🧾 *बिल संख्या:* #{invoice_no}
📅 *दिनांक:* {date}
💰 *कुल राशि:* {amount}

💳 *UPI से तुरंत भुगतान करें:*
{upi_link}

शुभकामनाएं!`,hinglish:`Namaste {customer_name},

*{store_name}* se shopping karne ke liye shukriya! 🙏

🧾 *Bill No:* #{invoice_no}
📅 *Date:* {date}
💰 *Bill Amount:* {amount}

💳 *UPI se payment karein:*
{upi_link}

Aapka din shubh ho!`},reminder:{en:`Dear {customer_name},

This is a friendly payment reminder from *{store_name}*.

Your invoice *#{invoice_no}* for *{amount}* is pending payment.

💳 *Pay Instantly via UPI:*
{upi_link}

Thank you!`,hi:`नमस्ते {customer_name},

*{store_name}* की ओर से सादर स्मरण।

आपका बिल *#{invoice_no}*, राशि *{amount}* का भुगतान अभी बाकी है।

💳 *UPI से तुरंत भुगतान करें:*
{upi_link}

सधन्यवाद!`,hinglish:`Namaste {customer_name},

Yeh *{store_name}* ki taraf se gentle payment reminder hai.

Aapka bill *#{invoice_no}* amount *{amount}* pending hai.

💳 *UPI se turant pay karein:*
{upi_link}

Dhanyawad!`},statement:{en:`Dear {customer_name},

Here is your ledger account summary from *{store_name}*.

Outstanding Due Balance: *{amount}*.

💳 *Clear balance via UPI:*
{upi_link}

Thank you for your valued partnership.`,hi:`नमस्ते {customer_name},

*{store_name}* द्वारा आपका खाता सारांश प्रस्तुत है।

बकाया राशि: *{amount}*.

💳 *UPI द्वारा तुरंत भुगतान करें:*
{upi_link}

धन्यवाद!`,hinglish:`Namaste {customer_name},

*{store_name}* ki taraf se aapka ledger statement.

Total Due Balance: *{amount}*.

💳 *UPI link se clear karein:*
{upi_link}

Shukriya!`}};function w(t,a,n={}){const r=n.language||"en",l=n.purpose||"invoice",o=n.overrideTemplate||M[l][r],d=t.upiId?`https://upiqr.in/?pa=${t.upiId}&pn=${encodeURIComponent(t.tradeName||t.businessName)}&am=${a.grandTotal.toFixed(2)}&tn=Inv_${a.invoiceNumber}`:"Cash / Bank Transfer",i=j(a.grandTotal),u=A(a.date);let c=o.replace(/{customer_name}/g,a.partyName||"Valued Customer").replace(/{store_name}/g,t.tradeName||t.businessName).replace(/{invoice_no}/g,a.invoiceNumber).replace(/{amount}/g,i).replace(/{date}/g,u).replace(/{upi_link}/g,d);const p=Math.max(0,n.totalBalanceDue??a.balanceAmount??0),x=r==="hi"?"📊 *कुल बकाया राशि:*":"📊 *Total Balance Due:*";return!c.includes("Total Balance Due")&&!c.includes("कुल बकाया राशि")&&(c+=`

${x} ${j(p)}`),c}function W(t,a,n={}){const r=w(t,a,n),{url:l}=D({phone:n.phoneNumber,text:r,channel:"api"});T(l)}const R=({invoice:t,company:a,onClose:n,initialPhone:r,totalBalanceDue:l})=>{C(()=>(n(),!0),!0,30);const[o,d]=m.useState("en"),[i,u]=m.useState("invoice"),c=r&&r.trim()||t.partyPhone&&t.partyPhone.trim()||"",[p,x]=m.useState(c),[h,b]=m.useState(""),[g,v]=m.useState(!1),y=w(a,t,{language:o,purpose:i,totalBalanceDue:l}),_=()=>{var s;(s=navigator==null?void 0:navigator.clipboard)!=null&&s.writeText?(navigator.clipboard.writeText(y),v(!0),f("Message copied to clipboard!"),setTimeout(()=>v(!1),2500)):f("Unable to access clipboard.")},P=()=>{const s=p.trim();if(s){const k=I(s);if(!k.valid){const N=S(k);b(N),f(N);return}}b(""),W(a,t,{phoneNumber:s||void 0,language:o,purpose:i,totalBalanceDue:l}),n()};return e.jsx("div",{className:"fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/60 backdrop-blur-sm animate-fade-in",children:e.jsxs("div",{className:"bg-surface-container-lowest rounded-3xl shadow-2xl max-w-md w-full overflow-hidden border border-outline-variant/30 flex flex-col",children:[e.jsxs("div",{className:"p-4 border-b border-outline-variant/20 flex items-center justify-between bg-[#25D366]/10",children:[e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx("span",{className:"material-symbols-outlined text-[#25D366] text-[24px]",children:"chat"}),e.jsxs("div",{children:[e.jsx("h3",{className:"font-headline-sm text-sm font-bold text-on-surface",children:"Share via WhatsApp"}),e.jsx("p",{className:"text-[11px] text-on-surface-variant",children:"Instant digital receipt & UPI payment link"})]})]}),e.jsx("button",{onClick:n,"aria-label":"Close share modal",className:"w-8 h-8 rounded-full flex items-center justify-center text-on-surface-variant hover:bg-surface-container cursor-pointer transition-colors",children:e.jsx("span",{className:"material-symbols-outlined text-[18px]",children:"close"})})]}),e.jsxs("div",{className:"p-4 space-y-3 flex-1 overflow-y-auto",children:[U()&&e.jsxs("div",{"data-testid":"whatsapp-demo-warning",className:"p-3 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-900 dark:text-amber-200 text-xs flex items-start gap-2.5",children:[e.jsx("span",{className:"material-symbols-outlined text-amber-600 dark:text-amber-400 text-[18px] shrink-0 mt-0.5",children:"info"}),e.jsx("p",{className:"leading-relaxed",children:"Demo Mode: this message uses demo data. Sending opens your real WhatsApp app; no production records are changed."})]}),e.jsxs("div",{children:[e.jsx("label",{className:"block text-[11px] font-bold text-on-surface-variant uppercase tracking-wider mb-1",children:"Customer Mobile / WhatsApp Number"}),e.jsxs("div",{className:"flex items-center bg-surface border border-outline-variant/40 rounded-xl px-3 py-2 text-sm text-on-surface font-mono",children:[e.jsx("span",{className:"text-on-surface-variant font-bold mr-1",children:"+91"}),e.jsx("input",{"data-testid":"whatsapp-phone-input",type:"tel",placeholder:"9876543210 (Optional)",value:p,onChange:s=>{x(s.target.value),h&&b("")},className:"w-full bg-transparent outline-none"})]}),h&&e.jsx("p",{"data-testid":"whatsapp-phone-error",className:"text-xs text-error mt-1 font-medium",children:h})]}),e.jsxs("div",{children:[e.jsx("label",{className:"block text-[11px] font-bold text-on-surface-variant uppercase tracking-wider mb-1",children:"Message Template"}),e.jsxs("div",{className:"grid grid-cols-3 gap-1 bg-surface-container-low p-1 rounded-xl border border-outline-variant/30",children:[e.jsx("button",{type:"button",onClick:()=>u("invoice"),className:`py-1.5 text-xs font-bold rounded-lg transition-colors cursor-pointer ${i==="invoice"?"bg-secondary text-on-secondary shadow-sm":"text-on-surface-variant hover:text-on-surface"}`,children:"Sale Bill"}),e.jsx("button",{type:"button",onClick:()=>u("reminder"),className:`py-1.5 text-xs font-bold rounded-lg transition-colors cursor-pointer ${i==="reminder"?"bg-secondary text-on-secondary shadow-sm":"text-on-surface-variant hover:text-on-surface"}`,children:"Due Reminder"}),e.jsx("button",{type:"button",onClick:()=>u("statement"),className:`py-1.5 text-xs font-bold rounded-lg transition-colors cursor-pointer ${i==="statement"?"bg-secondary text-on-secondary shadow-sm":"text-on-surface-variant hover:text-on-surface"}`,children:"Statement"})]})]}),e.jsxs("div",{children:[e.jsx("label",{className:"block text-[11px] font-bold text-on-surface-variant uppercase tracking-wider mb-1",children:"Vernacular Language"}),e.jsxs("div",{className:"grid grid-cols-3 gap-1 bg-surface-container-low p-1 rounded-xl border border-outline-variant/30",children:[e.jsx("button",{type:"button",onClick:()=>d("en"),className:`py-1.5 text-xs font-bold rounded-lg transition-colors cursor-pointer ${o==="en"?"bg-secondary text-on-secondary shadow-sm":"text-on-surface-variant hover:text-on-surface"}`,children:"English"}),e.jsx("button",{type:"button",onClick:()=>d("hi"),className:`py-1.5 text-xs font-bold rounded-lg transition-colors cursor-pointer ${o==="hi"?"bg-secondary text-on-secondary shadow-sm":"text-on-surface-variant hover:text-on-surface"}`,children:"हिंदी (Hindi)"}),e.jsx("button",{type:"button",onClick:()=>d("hinglish"),className:`py-1.5 text-xs font-bold rounded-lg transition-colors cursor-pointer ${o==="hinglish"?"bg-secondary text-on-secondary shadow-sm":"text-on-surface-variant hover:text-on-surface"}`,children:"Hinglish"})]})]}),e.jsxs("div",{children:[e.jsx("label",{className:"block text-[11px] font-bold text-on-surface-variant uppercase tracking-wider mb-1",children:"Message Preview"}),e.jsx("div",{className:"bg-[#e7fedb] border border-[#25D366]/40 p-3.5 rounded-2xl text-xs font-sans text-neutral-900 whitespace-pre-wrap leading-relaxed shadow-sm",children:y})]})]}),e.jsxs("div",{className:"p-4 border-t border-outline-variant/20 bg-surface-container-low/40 flex items-center justify-between gap-2",children:[e.jsx("button",{type:"button",onClick:n,className:"px-4 py-2 border border-outline-variant/40 rounded-xl text-xs font-bold text-on-surface hover:bg-surface cursor-pointer",children:"Cancel"}),e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsxs("button",{type:"button","data-testid":"whatsapp-copy-button",onClick:_,className:"px-4 py-2 border border-secondary text-secondary rounded-xl text-xs font-bold hover:bg-secondary/10 cursor-pointer flex items-center gap-1.5",children:[e.jsx("span",{className:"material-symbols-outlined text-[16px]",children:g?"check":"content_copy"}),e.jsx("span",{children:g?"Copied":"Copy Message"})]}),e.jsxs("button",{type:"button","data-testid":"whatsapp-send-button",onClick:P,className:"px-6 py-2.5 bg-[#25D366] text-white rounded-xl text-xs font-bold shadow-md hover:bg-[#20bd5a] active:scale-95 transition-all cursor-pointer flex items-center gap-1.5",children:[e.jsx("span",{className:"material-symbols-outlined text-[18px]",children:"send"}),e.jsx("span",{children:"Send on WhatsApp"})]})]})]})]})})};export{R as W};

import{R as S,j as e}from"./vendor-react-BmrtlWLx.js";import{A as C,V as s,a as n,f as P,C as A,x as E}from"./index-5SGrcM_r.js";import{PurchaseDocumentModal as R}from"./PurchaseDocumentModal-CAU1WpQs.js";import{D as k,a as I}from"./DocumentTaxSummary-BMpIfG-Z.js";import"./vendor-capacitor-BjPRKokX.js";import"./vendor-pouchdb-cVEZlOt_.js";import"./vendor-icons-BshCZaD0.js";import"./pricing-zI0ToCXQ.js";function B(t,a){const d=s(t.tradeName||t.businessName||"Business Enterprise"),m=s(t.address||""),l=s(t.phone||""),g=s(t.gstin||""),u=a.purchaseType==="CHALLAN",o=a.purchaseType==="PO",p=a.purchaseType==="RETURN",c=u?"DELIVERY CHALLAN / GRN":o?"PURCHASE ORDER":p?"PURCHASE RETURN / DEBIT NOTE":"PURCHASE BILL",h=s(a.billNumber||a.id),b=s(a.supplierName||"Cash Supplier"),x=s(a.supplierAddress||""),f=s(a.supplierGstin||""),y=a.notes?s(a.notes):"",v=(a.items||[]).map((r,N)=>`
    <tr style="border-bottom: 1px solid #e2e8f0; font-size: 11px;">
      <td style="padding: 7px 6px; text-align: center; color: #64748b;">${N+1}</td>
      <td style="padding: 7px 8px; font-weight: 600; color: #0f172a;">${s(r.name)}</td>
      <td style="padding: 7px 6px; text-align: center; color: #475569;">${s(r.hsnSacCode||"—")}</td>
      <td style="padding: 7px 6px; text-align: center; font-weight: 600;">${r.quantity} ${s(r.unit||"")}</td>
      <td style="padding: 7px 8px; text-align: right;">${n(r.unitPrice)}</td>
      <td style="padding: 7px 8px; text-align: right;">${n(r.taxableAmount)}</td>
      <td style="padding: 7px 6px; text-align: center;">${r.gstRate||0}%</td>
      <td style="padding: 7px 8px; text-align: right; font-weight: 700; color: #0f172a;">${n(r.totalAmount)}</td>
    </tr>
  `).join("");return`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>${c} - #${h}</title>
  <style>
    @page {
      size: A4 portrait;
      margin: 12mm 15mm;
    }
    * {
      box-sizing: border-box;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      padding: 20px;
      color: #1e293b;
      max-width: 800px;
      margin: 0 auto;
      background: #ffffff;
      line-height: 1.4;
      font-size: 11px;
    }
    .header {
      border-bottom: 2px solid #0f172a;
      padding-bottom: 10px;
      margin-bottom: 12px;
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
    }
    .company-title {
      font-size: 18px;
      font-weight: 800;
      color: #0f172a;
    }
    .doc-badge {
      font-size: 15px;
      font-weight: 800;
      color: #ea580c;
      text-align: right;
      text-transform: uppercase;
    }
    .meta-box {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 12px;
      margin-bottom: 14px;
      font-size: 11.5px;
    }
    .card {
      background: #f8fafc;
      border: 1px solid #e2e8f0;
      border-radius: 6px;
      padding: 10px 12px;
    }
    .card-title {
      font-size: 10px;
      text-transform: uppercase;
      font-weight: 700;
      color: #64748b;
      margin-bottom: 4px;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 8px;
      font-size: 10.5px;
    }
    th {
      background: #f1f5f9;
      color: #0f172a;
      font-weight: 700;
      border-top: 1px solid #cbd5e1;
      border-bottom: 2px solid #0f172a;
      padding: 6px 8px;
    }
    tfoot td {
      background: #f8fafc;
      font-weight: 700;
      border-top: 1px solid #cbd5e1;
      padding: 6px 8px;
    }
    .totals-area {
      display: flex;
      justify-content: flex-end;
      margin-top: 12px;
    }
    .totals-table {
      width: 280px;
      font-size: 11px;
    }
    .totals-table td {
      padding: 3px 6px;
    }
    .grand-total-row td {
      border-top: 2px solid #0f172a;
      border-bottom: 2px solid #0f172a;
      font-size: 13px;
      font-weight: 800;
      color: #0f172a;
      padding: 6px;
    }
    .notes-box {
      margin-top: 14px;
      padding: 8px 10px;
      background: #f8fafc;
      border-radius: 6px;
      font-size: 11px;
      color: #475569;
    }
    .signatures {
      display: flex;
      justify-content: space-between;
      margin-top: 45px;
      font-size: 11px;
      font-weight: 600;
      color: #334155;
    }
    .sig-line {
      border-top: 1px dashed #94a3b8;
      padding-top: 5px;
      width: 170px;
      text-align: center;
    }
    .footer {
      border-top: 1px dashed #cbd5e1;
      margin-top: 24px;
      padding-top: 8px;
      font-size: 9.5px;
      text-align: center;
      color: #94a3b8;
    }
    @media print {
      body {
        padding: 0;
      }
      .no-print {
        display: none !important;
      }
    }
  </style>
</head>
<body>
  <div class="no-print" style="margin-bottom: 16px; display: flex; justify-content: flex-end; gap: 10px;">
    <button onclick="window.print()" style="padding: 8px 16px; background: #0284c7; color: #fff; border: none; border-radius: 6px; font-weight: bold; cursor: pointer;">Print / Save as PDF</button>
    <button onclick="window.close()" style="padding: 8px 16px; background: #e2e8f0; color: #0f172a; border: none; border-radius: 6px; font-weight: bold; cursor: pointer;">Close</button>
  </div>
  <div class="header">
    <div>
      <div class="company-title">${d}</div>
      <div style="font-size: 11px; color: #64748b; margin-top: 2px;">
        ${g?`<div>GSTIN: ${g}</div>`:""}
        ${m?`<div>${m}</div>`:""}
        ${l?`<div>Phone: ${l}</div>`:""}
      </div>
    </div>
    <div>
      <div class="doc-badge">${c}</div>
      <div style="font-size: 12px; font-weight: 700; color: #0f172a; text-align: right; margin-top: 2px;">
        #${h}
      </div>
      <div style="font-size: 11px; color: #64748b; text-align: right; margin-top: 2px;">
        Date: ${P(a.date)}
      </div>
    </div>
  </div>

  <div class="meta-box">
    <div class="card">
      <div class="card-title">Supplier Details</div>
      <div style="font-weight: 700; font-size: 12px; color: #0f172a;">${b}</div>
      ${f?`<div>GSTIN: ${f}</div>`:""}
      ${x?`<div>${x}</div>`:""}
    </div>
    <div class="card">
      <div class="card-title">Billing & Payment Summary</div>
      <div><strong>Status:</strong> ${a.paymentStatus||"UNPAID"}</div>
      <div><strong>Mode:</strong> ${a.paymentMode||"CASH"}</div>
      ${a.paidAmount>0?`<div><strong>Paid:</strong> ${n(a.paidAmount)}</div>`:""}
      <div><strong>Balance Due:</strong> ${n(a.balanceAmount||0)}</div>
    </div>
  </div>

  <table>
    <thead>
      <tr>
        <th style="width: 30px; text-align: center;">#</th>
        <th style="text-align: left;">Item Description</th>
        <th style="width: 70px; text-align: center;">HSN</th>
        <th style="width: 70px; text-align: center;">Qty</th>
        <th style="width: 85px; text-align: right;">Rate</th>
        <th style="width: 90px; text-align: right;">Taxable</th>
        <th style="width: 55px; text-align: center;">GST</th>
        <th style="width: 95px; text-align: right;">Total</th>
      </tr>
    </thead>
    <tbody>
      ${v||'<tr><td colspan="8" style="text-align: center; padding: 15px; color: #94a3b8;">No items listed</td></tr>'}
    </tbody>
  </table>

  <div class="totals-area">
    <table class="totals-table">
      <tr>
        <td style="color: #64748b;">Taxable Total:</td>
        <td style="text-align: right; font-weight: 600;">${n(a.totalTaxableAmount||a.totalGrossAmount)}</td>
      </tr>
      ${a.totalTax?`<tr><td style="color: #64748b;">Total GST:</td><td style="text-align: right; font-weight: 600;">${n(a.totalTax)}</td></tr>`:""}
      ${a.roundOff?`<tr><td style="color: #64748b;">Round Off:</td><td style="text-align: right;">${n(a.roundOff)}</td></tr>`:""}
      <tr class="grand-total-row">
        <td>Grand Total:</td>
        <td style="text-align: right;">${n(a.grandTotal)}</td>
      </tr>
    </table>
  </div>

  ${y?`<div class="notes-box"><strong>Notes / Terms:</strong> ${y}</div>`:""}

  <div class="signatures">
    <div class="sig-line">Supplier Signature</div>
    <div class="sig-line">For ${d}</div>
  </div>

  <div class="footer">
    Generated automatically by Vyapar Books PRO Inward Logistics Engine
  </div>
</body>
</html>`}function D(t,a){const d=B(t,a);C(d,`Purchase-${a.billNumber||a.id}`,"A4")}const V=({bill:t,company:a,onClose:d,onEditPurchase:m,onDeletePurchase:l})=>{var w;const[g,u]=S.useState(!1);if(!t)return null;const o=t.purchaseType==="CHALLAN",p=t.purchaseType==="PO",c=t.purchaseType==="RETURN",h=t.paymentStatus==="PAID",b=t.paymentStatus==="PARTIAL",x=a.isGstEnabled!==!1,f=()=>{l&&u(!0)},y=o?`Challan #${t.billNumber}`:p?`PO #${t.billNumber}`:c?`Debit Note #${t.billNumber}`:`Bill #${t.billNumber}`,v=o?"move_to_inbox":p?"add_shopping_cart":c?"assignment_turned_in":"shopping_bag",r=o?"bg-teal-500/15 text-teal-600 dark:text-teal-400":p?"bg-indigo-500/15 text-indigo-600 dark:text-indigo-400":c?"bg-amber-500/15 text-amber-600 dark:text-amber-400":"bg-orange-500/15 text-orange-600 dark:text-orange-400",N=e.jsxs("div",{className:"flex items-center gap-1.5 flex-wrap",children:[e.jsx("h3",{className:"font-bold text-sm text-on-surface truncate",children:y}),o?e.jsx("span",{className:"text-[9px] font-bold px-1.5 py-0.2 rounded-full bg-teal-500/15 text-teal-700 dark:text-teal-300",children:t.isConverted?"CONVERTED":t.challanStatus||"RECEIVED"}):e.jsx("span",{className:`text-[9px] font-bold px-1.5 py-0.2 rounded-full ${h?"bg-secondary/15 text-secondary":b?"bg-amber-500/15 text-amber-600 dark:text-amber-400":"bg-error/15 text-error"}`,children:t.paymentStatus})]}),$=()=>{const i=`Purchase-${t.billNumber||t.id}`;E(i)||D(a,t)},T=e.jsxs("div",{className:"flex items-center justify-end gap-2",children:[e.jsxs("button",{type:"button",onClick:$,className:"min-h-[44px] py-2 px-3.5 rounded-xl bg-surface-container-lowest text-on-surface border border-outline-variant/30 font-bold text-xs flex items-center justify-center gap-1.5 hover:bg-surface-container active:scale-95 transition-all cursor-pointer",title:o?"Print Purchase Challan":"Print Purchase Bill",children:[e.jsx("span",{className:"material-symbols-outlined text-[16px]",children:"print"}),e.jsx("span",{children:"Print"})]}),l&&e.jsxs("button",{type:"button",onClick:f,className:"min-h-[44px] py-2 px-3.5 rounded-xl text-error hover:bg-error/10 font-bold text-xs flex items-center justify-center gap-1 cursor-pointer transition-colors active:scale-95",title:o?"Delete Purchase Challan":"Delete Purchase Bill",children:[e.jsx("span",{className:"material-symbols-outlined text-[16px]",children:"delete"}),e.jsx("span",{children:"Delete"})]}),m&&(!t.isConverted||p)&&e.jsxs("button",{type:"button",onClick:()=>{d(),m(t)},className:"min-h-[44px] py-2 px-4 rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs cursor-pointer flex items-center justify-center gap-1 active:scale-95 transition-all shadow-xs",title:o?"Edit Purchase Challan":"Edit Purchase Bill",children:[e.jsx("span",{className:"material-symbols-outlined text-[16px]",children:"edit"}),e.jsx("span",{children:o?"Edit Challan":p?"Edit PO":"Edit Bill"})]})]});return e.jsxs(e.Fragment,{children:[e.jsxs(R,{isOpen:!!t,onClose:d,title:N,headerLeading:e.jsx("div",{className:`w-8 h-8 rounded-xl ${r} flex items-center justify-center flex-shrink-0`,children:e.jsx("span",{className:"material-symbols-outlined text-[18px]",children:v})}),closeAriaLabel:"Close purchase details",maxWidth:"md",customFooter:T,backNavPriority:25,children:[x&&e.jsxs("div",{className:"flex items-center justify-between text-[11px] text-on-surface-variant bg-surface-container-low/70 py-1.5 px-2.5 rounded-xl",children:[e.jsxs("span",{children:["GSTIN: ",e.jsx("strong",{className:"font-mono text-on-surface",children:t.supplierGstin||"Unregistered"})]}),e.jsxs("span",{children:["ITC: ",e.jsx("strong",{className:"text-on-surface",children:t.itcEligibility==="INELIGIBLE_17_5"||t.itcEligibility==="INELIGIBLE_OTHERS"?"Blocked":"Eligible"})]})]}),e.jsx(k,{mode:"compact",kind:"purchase",rows:t.items,isGstActive:x,isCompositionScheme:a.isCompositionScheme}),e.jsx(I,{variant:"compact",title:"Total Bill Value",totalTaxableAmount:t.totalTaxableAmount,totalTax:t.totalTax,totalCess:t.totalCess,finalGrandTotal:t.grandTotal,isGstActive:x,isCompositionScheme:a.isCompositionScheme,accentColor:"orange"}),o?e.jsxs("div",{className:"flex flex-col gap-1 px-3 py-1.5 rounded-xl bg-teal-500/10 text-xs border border-teal-500/20",children:[e.jsxs("div",{className:"flex items-center justify-between text-teal-800 dark:text-teal-300",children:[e.jsxs("span",{className:"text-[11px] font-semibold flex items-center gap-1",children:[e.jsx("span",{className:"material-symbols-outlined text-[14px]",children:"inventory"}),"Goods Receipt Note (GRN):"]}),e.jsx("span",{className:"text-[11px] font-bold",children:t.isConverted?`Converted to Bill #${t.convertedToBillNumber}`:"Inward Stock Recorded"})]}),(t.vehicleNumber||t.transporterName||t.lrNumber||t.ewayBillNumber)&&e.jsxs("div",{className:"flex flex-wrap gap-2 pt-1 border-t border-teal-500/20 text-[10px] text-teal-700 dark:text-teal-300 font-medium",children:[t.vehicleNumber&&e.jsxs("span",{children:["Vehicle: ",t.vehicleNumber]}),t.transporterName&&e.jsxs("span",{children:["Transporter: ",t.transporterName]}),t.lrNumber&&e.jsxs("span",{children:["LR #: ",t.lrNumber]}),t.ewayBillNumber&&e.jsxs("span",{children:["E-Way: ",t.ewayBillNumber]})]})]}):e.jsxs("div",{className:"flex flex-col gap-1 px-3 py-1.5 rounded-xl bg-surface-container text-xs",children:[e.jsxs("div",{className:"flex items-center justify-between",children:[e.jsxs("span",{className:"text-[11px] text-on-surface-variant font-medium",children:["Payment (",t.paymentMode==="SPLIT"?"Split Tender":t.paymentMode||"Cash","):"]}),e.jsx("span",{className:"text-[11px] font-bold",children:t.balanceAmount<=.01?e.jsxs("span",{className:"text-secondary flex items-center gap-1 font-bold",children:[e.jsx("span",{className:"material-symbols-outlined text-[15px]",children:"check_circle"}),"Fully Settled"]}):e.jsxs("span",{className:"text-on-surface",children:["Paid: ",e.jsx("span",{className:"text-secondary",children:n(t.paidAmount)})," • Due:"," ",e.jsx("span",{className:"text-error",children:n(t.balanceAmount)})]})})]}),(t.paymentSplits&&t.paymentSplits.length>1||t.notes&&t.notes.includes("Split"))&&e.jsx("div",{className:"flex flex-wrap gap-1.5 pt-0.5 border-t border-outline-variant/15 text-[10px]",children:t.paymentSplits&&t.paymentSplits.length>0?t.paymentSplits.filter(i=>i.mode!=="CREDIT"&&i.amount>0).map((i,j)=>e.jsxs("span",{className:"px-1.5 py-0.5 rounded bg-surface-container-high font-semibold text-on-surface-variant",children:[i.mode,": ",n(i.amount)]},j)):(((w=t.notes)==null?void 0:w.replace("Split Payment — ",""))||"").split(", ").map((i,j)=>e.jsx("span",{className:"px-1.5 py-0.5 rounded bg-surface-container-high font-semibold text-on-surface-variant",children:i},j))})]})]}),g&&e.jsx(A,{isOpen:g,title:"Delete Purchase Bill?",recordName:`Bill #${t.billNumber}`,description:"Are you sure you want to delete this purchase bill? This will revert any stock added by this bill.",confirmText:"Delete Purchase",onConfirm:()=>{l==null||l(t.id),d()},onClose:()=>u(!1)})]})};export{V as SimplifiedPurchaseModal};
